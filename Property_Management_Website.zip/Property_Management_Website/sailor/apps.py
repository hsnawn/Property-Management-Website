from django.apps import AppConfig


class SailorConfig(AppConfig):
    name = 'sailor'
