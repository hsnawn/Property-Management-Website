create schema booking;

CREATE TABLE Property_Company
(
  Name VARCHAR(30) NOT NULL,
  Country VARCHAR(50),
  State VARCHAR(50),
  City VARCHAR(50),
  Contact varchar(30),
  #Email is additional was not added in ER
  Email VARCHAR(30),
  foreign key Contact(Contact)
	references Property_company_contact(Contact)
	 on delete set null
     on update cascade,
  PRIMARY KEY (Name)
);

#Company can store more than one contact numbers
CREATE TABLE Property_company_contact
(
 Contact varchar(30),
 primary key(Contact)
);

CREATE TABLE Newsletter
(
  Email VARCHAR(30) NOT NULL,
  PRIMARY KEY (Email)
);


CREATE TABLE Advertisement
(
  Type VARCHAR(30), #Apartment,house,villa
  Price VARCHAR(30),
  Id INT NOT NULL,
  Title VARCHAR(30) NOT NULL,
  Listing_type VARCHAR(30) NOT NULL,
  Bedrooms int,
  Bathrooms int,
  Floor_number int,
  Neigborhood char(200),
  Description VARCHAR(500) NOT NULL,
  Built_up_year varchar(15),
  Ad_price_type varchar(30) not null,
  Expiry DATE NOT NULL,
  Status VARCHAR(30) NOT NULL,
  Area VARCHAR(30) NOT NULL,
  Country VARCHAR(30) NOT NULL,
  State VARCHAR(30) NOT NULL,
  City VARCHAR(30) NOT NULL,
  PRIMARY KEY (Id)
);

CREATE TABLE Agent
(
  Email VARCHAR(30) NOT NULL,
  Firstname VARCHAR(30),
  Lastname VARCHAR(30),
  Username VARCHAR(30) NOT NULL,
  Contact varchar(35) NOT NULL,
  Password varchar(35) not null,
  Agency_Name varchar(40),
  Rating int,
  PRIMARY KEY (Username),
  UNIQUE (Contact)
);

